﻿Public Class GlobalV
    Public Shared cart_count = 0
    Public Shared cart_products = {}

End Class
