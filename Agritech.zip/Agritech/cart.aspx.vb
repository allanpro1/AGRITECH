﻿Imports System.Data.OleDb

Public Class WebForm2
    Inherits System.Web.UI.Page

    Public kags = "ola dora"
    Dim dbconn, sql, dbcomm, dbread

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        dbconn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; data source=" & Server.MapPath("agritech_db.mdb"))
        dbconn.Open()
        'sql = "SELECT orders.order_id, orders.product_id, orders.user_id FROM orders INNER JOIN products ON orders.product_id=products.product_id"
        sql = "SELECT * FROM products INNER JOIN orders ON orders.product_id=products.product_id"
        dbcomm = New OleDbCommand(sql, dbconn)
        dbread = dbcomm.ExecuteReader()
        mycart.DataSource = dbread
        mycart.DataBind()
        dbread.Close()
        dbconn.Close()
    End Sub

    Protected Sub removeOrder(sender As Object, e As EventArgs)
        Dim sql = "DELETE FROM orders WHERE order_id='ord4'"
        Dim cmd = New OleDbCommand(sql, dbconn)
        dbconn.Open()
        cmd.ExecuteNonQuery()
    End Sub

End Class