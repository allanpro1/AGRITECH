﻿Imports System.Data.OleDb

Public Class WebForm1
    Inherits System.Web.UI.Page

    Private Shared no_cart_items = GlobalV.cart_count

    Dim dbconn, sql, dbcomm, dbread

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        dbconn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; data source=" & Server.MapPath("agritech_db.mdb"))
        dbconn.Open()
        sql = "SELECT * FROM Products"
        dbcomm = New OleDbCommand(sql, dbconn)
        dbread = dbcomm.ExecuteReader()
        products3.DataSource = dbread
        products3.DataBind()
        dbread.Close()
        dbconn.Close()

    End Sub

    Protected Sub addToCart(sender As Object, e As EventArgs)
        If IsPostBack Then
            GlobalV.cart_count += 1
            cart_items.InnerText = Request("cart_product_id") 'GlobalV.cart_count
            ReDim GlobalV.cart_products(GlobalV.cart_products.Length)
            GlobalV.cart_products(GlobalV.cart_products.Length - 1) = "45"

            Dim sql = "INSERT INTO orders VALUES (@orderid, @productid, @userid)"
            Dim cmd = New OleDbCommand(sql, dbconn)
            cmd.Parameters.AddWithValue("@orderid", "ord4")
            cmd.Parameters.AddWithValue("@productid", "prod4")
            cmd.Parameters.AddWithValue("@userid", "user1")
            dbconn.Open()
            cmd.ExecuteNonQuery()


        End If
    End Sub

End Class